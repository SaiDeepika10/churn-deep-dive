# Churn Playbook

> Automated and human-led intervention rules, matched to risk level and customer value.
> Review and recalibrate every quarter.

---

## Automated Triggers

### Rule 1 — 7-day inactivity → Re-engagement email
```
IF last_login >= 7 days
AND plan != 'enterprise'
AND churned = false
→ Send re-engagement email with last 3 actions + how-to video
```
- **Expected impact:** Prevents ~22% of churns in segment
- **Avg open rate:** 41%
- **Owner:** Marketing automation

---

### Rule 2 — Usage drop 50%+ → In-app prompt
```
IF wk_sessions / prev_wk_sessions < 0.5
AND tenure_days > 14
AND churned = false
→ Trigger in-app nudge with 2 unused features + live chat CTA
```
- **Expected impact:** Prevents ~18% of churns
- **CTR:** 14%
- **Owner:** Product / Growth

---

### Rule 3 — NPS ≤ 4 → Immediate follow-up survey
```
IF nps_score <= 4
AND survey_response_date IS NULL
→ Send 2-question micro-survey within 1 hour
→ Route responses to product team
```
- **Response rate:** 38%
- **Expected impact:** Prevents ~11% of churns
- **Owner:** Customer Success + Product

---

### Rule 4 — 14-day inactivity (starter) → Downgrade/upgrade offer
```
IF last_login >= 14 days
AND plan = 'starter'
AND churned = false
→ Offer 30% discount to upgrade OR graceful downgrade to free
```
- **Upgrade conversion:** 9%
- **Cancellation avoided:** 31%
- **Owner:** Marketing / Billing

---

## Human-Led Interventions

### Rule 5 — High-value at-risk → Assign dedicated CSM
```
IF mrr >= 500
AND risk_signals >= 2
→ Create CSM task within 4h
→ Send personal check-in email within 24h (NO automation)
```
- **Expected impact:** Prevents ~44% of churns in segment
- **Avg save value:** $1,240/mo
- **Owner:** Customer Success Lead

---

### Rule 6 — 3+ unresolved tickets → Escalation call
```
IF open_tickets >= 3
AND ticket_age >= 5 days
→ CS team lead books 20-min call
→ If product bug: create P1 ticket, notify customer of fix timeline
```
- **Resolution rate:** 74%
- **CSAT after call:** 4.2/5
- **Owner:** Head of Support

---

### Rule 7 — New customers → 30-day onboarding sequence
```
IF tenure_days IN (7, 14, 30)
AND core_features_activated = false
→ Proactive email from onboarding rep
→ Goal: activate dashboard + 1 integration before day 30
```
- **Activation lift:** +38%
- **Month-1 churn reduction:** -29%
- **Owner:** Onboarding team

---

## Risk Score Thresholds

| Risk tier | Churn probability | Primary action |
|-----------|------------------|----------------|
| Low | 0–20% | Monitor, standard comms |
| Medium | 20–50% | Automated trigger rules 1–4 |
| High | 50–75% | Automated + human rules 5–7 |
| Critical | 75–100% | Immediate CSM escalation |

---

## Metrics to Track

- **Playback save rate** — % of at-risk customers retained after intervention
- **Time-to-intervention** — avg hours from signal to first outreach
- **Segment churn rate** — monthly, by plan + acquisition channel
- **Feature activation rate** — % of new customers activating core features by day 30

---

*Last updated: June 2024 · Next review: September 2024*
